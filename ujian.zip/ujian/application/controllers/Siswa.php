<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Siswa extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Siswa_model');
        // is_logged_in();
    }

    public function index()
    {
        $data['pemilih'] = $this->db->get('pemilih')->result_array();

        // $this->load->view('template/header');
        $this->load->view('siswa/index', $data);
        // $this->load->view('template/footer');
    }

    public function tambah(){   
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('nisn', 'NISN', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');

        if ($this->form_validation->run() == FALSE) {
            // $this->load->view('template/header');
            $this->load->view('siswa/tambah');
            // $this->load->view('template/footer');
        } else {
            $this->Siswa_model->tambah();
            redirect('pemilih');
        }
    }

    public function edit($id){
        $data['pemilih'] =$this->Siswa_model->getId($id);
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('nisn', 'nisn', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');

        $data['siswa'] = $this->Siswa_model->getId($id);

        if ($this->form_validation->run() == FALSE) {
            // $this->load->view('template/header');
            $this->load->view('siswa/edit', $data);
            // $this->load->view('template/footer');
        } else {
            $this->Siswa_model->edit($id);
            redirect('siswa');
        }
    }

    public function hapus($id){
        $this->Siswa_model->hapus($id);
        redirect('siswa');
    }
}
