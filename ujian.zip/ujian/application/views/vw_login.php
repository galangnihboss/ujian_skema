<!-- <html>
	<head>
		<title>Form Login</title>
		<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">
	</head>
	<body>
	<div class="container">
		<div class="card mt-5">
			<div class="card-header">
				<b>Login Pemilih</b>
			</div>
			<div class="card-body">

				<?php 
				if($this->session->flashdata('success_register') !='')
				{
					echo '<div class="" role="alert">';
					echo $this->session->flashdata('');
					echo '</div>';
				}
				?>
				<form method="post" action="<?php echo base_url('index.php/login/proses'); ?>">
					<div class="form-group">
						<label for="username">Username</label>
						<input type="text" class="form-control" name="username" id="username" placeholder="Enter Username">
					</div>
					<div class="form-group">
						<label for="password">Password</label>
						<input type="password" class="form-control" name="password" id="password" placeholder="Password">
					</div>
					<!-- <button type="submit" class="btn btn-outline-warning">Login</button> -->
					<button type="submit" class="btn btn-outline-primary">Login</button>
					<a href="<?php echo base_url('admin'); ?>">
						<button type="button" class="btn btn-outline-warning">Login admin</button>
					</a>
				</form>
			</div>
		</div>
	</div>		
	</body>
</html> -->
